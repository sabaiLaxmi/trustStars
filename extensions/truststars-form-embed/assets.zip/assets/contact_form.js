function initTrustStarsForms() {
  const wrappers = document.querySelectorAll('.ts-block-wrapper:not(.ts-initialized)');
  
  wrappers.forEach(async (wrapper) => {
    wrapper.classList.add('ts-initialized'); // Mark as initialized
    const formId = wrapper.getAttribute('data-form-id');
    const blockId = wrapper.getAttribute('data-block-id');
    const container = document.getElementById(`ts-form-container-${blockId}`);
    
    if (!formId) return;

    try {
      // Fetch form configuration
      const response = await fetch(`/apps/truststars/api/${formId}`);
      const data = await response.json();
      
      if (!response.ok) {
        if (data.error === "NoPublishedForms") {
          throw new Error('NoPublishedForms');
        }
        throw new Error('Form not found');
      }
      
      if (!data.form) throw new Error('Form data invalid');
      
      const form = data.form;
      
      // Build Form HTML
      let fieldsHtml = '';
      form.fields.forEach(field => {
        const requiredAttr = field.required ? 'required' : '';
        const requiredAsterisk = field.required ? '<span class="ts-required" style="color: inherit;">*</span>' : '';
        
        if (field.type === 'TEXTAREA') {
          fieldsHtml += `
            <div class="ts-form-group">
              <label class="ts-label" for="${field.id}" style="color: inherit; font-family: inherit;">${field.label} ${requiredAsterisk}</label>
              <textarea id="${field.id}" name="${field.id}" class="ts-input ts-textarea" placeholder="${field.placeholder || ''}" rows="4" style="font-family: inherit;" ${requiredAttr}></textarea>
            </div>
          `;
        } else {
          const type = field.type === 'EMAIL' ? 'email' : 'text';
          fieldsHtml += `
            <div class="ts-form-group">
              <label class="ts-label" for="${field.id}" style="color: inherit; font-family: inherit;">${field.label} ${requiredAsterisk}</label>
              <input type="${type}" id="${field.id}" name="${field.id}" class="ts-input" placeholder="${field.placeholder || ''}" style="font-family: inherit;" ${requiredAttr} />
            </div>
          `;
        }
      });

      const FONT_MAP = {
        'Serif': 'Georgia, serif',
        'Rounded': '"Varela Round", "Nunito", ui-rounded, sans-serif',
        'Modern': '"Inter", "Roboto", "Helvetica Neue", sans-serif',
        'Default': 'inherit'
      };

      const bgColor = form.backgroundColor || form.accentColor || 'transparent';
      const txtColor = form.textColor || 'inherit';
      const fontFam = form.fontFamily && FONT_MAP[form.fontFamily] ? FONT_MAP[form.fontFamily] : 'inherit';
      const btnBg = form.backgroundColor ? txtColor : '';
      const btnText = form.backgroundColor ? bgColor : '';
      const btnStyle = btnBg ? `style="background-color: ${btnBg}; color: ${btnText}; border: none;"` : '';

      let imagesHtml = '';
      if (form.images) {
        try {
          const imagesArray = JSON.parse(form.images);
          if (imagesArray && imagesArray.length > 0) {
            imagesHtml = '<div style="display: flex; gap: 8px; margin-bottom: 16px; overflow-x: auto;">' + 
                         imagesArray.map(src => `<img src="${src}" style="max-width: 100%; max-height: 300px; border-radius: 8px; object-fit: cover; flex: 1; min-width: 0;" />`).join('') +
                         '</div>';
          }
        } catch (e) {
          console.error("Failed to parse images", e);
        }
      }

      let brandingHtml = '';
      if (!form.removeBranding) {
        brandingHtml = `<div style="text-align: center; margin-top: 16px; font-size: 12px; opacity: 0.8; color: ${txtColor};">Powered by <strong>TrustStars</strong></div>`;
      }

      container.innerHTML = `
        <div class="ts-form-inner" style="background-color: ${bgColor}; color: ${txtColor}; font-family: ${fontFam}; padding: 24px; border-radius: 8px;">
          ${imagesHtml}

          
          <form id="ts-form-${blockId}" class="ts-form" action="/apps/truststars/api/${formId}" method="POST">
            ${fieldsHtml}
            
            <div style="display: none;" aria-hidden="true">
              <label for="a_password">Password</label>
              <input type="text" id="a_password" name="a_password" tabindex="-1" autocomplete="off" />
            </div>
            
            <button type="submit" class="ts-submit-btn button btn" ${btnStyle}>${form.submitText || 'Submit'}</button>
          </form>
          
          <div id="ts-success-${blockId}" class="ts-success-message" style="display: none;">
            <div class="ts-success-icon">✓</div>
            <h3 class="ts-success-text">Thank You!</h3>
            <p>Your submission has been received.</p>
          </div>
          
          <div id="ts-error-${blockId}" class="ts-error-message" style="display: none; color: red; margin-top: 10px;">
            There was an error submitting the form. Please check your inputs.
          </div>
          
          ${brandingHtml}
        </div>
      `;
      
      // Handle Submission
      const formEl = document.getElementById(`ts-form-${blockId}`);
      formEl.addEventListener('submit', async function(e) {
        e.preventDefault();
        const submitBtn = formEl.querySelector('.ts-submit-btn');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';
        
        const formData = new FormData(formEl);
        
        try {
          const res = await fetch(formEl.action, {
            method: 'POST',
            body: formData
          });
          const result = await res.json();
          
          if (result.success) {
            formEl.style.display = 'none';
            document.getElementById(`ts-success-${blockId}`).style.display = 'block';
            document.getElementById(`ts-error-${blockId}`).style.display = 'none';
            
            try {
              if (window.emailjs) {
                const emailConfig = data.emailjsConfig || {};
                const publicKey = emailConfig.publicKey;
                const serviceId = emailConfig.serviceId;
                const templateCustomer = emailConfig.templateCustomer;
                const templateMerchant = emailConfig.templateMerchant;
                const shopEmail = wrapper.getAttribute('data-shop-email');

                if (publicKey && serviceId) {
                  const templateParams = {
                    merchant_email: shopEmail
                  };
                  
                  let customerEmail = '';
                  let allDetails = "";

                  form.fields.forEach(field => {
                    const val = formData.get(field.id) || '';
                    if (field.type === 'EMAIL' || field.label.toLowerCase().includes('email')) {
                      if (val.trim()) {
                        customerEmail = val.trim();
                      }
                    }
                    const lowerLabel = field.label.toLowerCase();
                    
                    // Fuzzy match existing template keys
                    if (lowerLabel.includes('name')) templateParams['Full Name'] = val;
                    if (lowerLabel.includes('email')) templateParams['Email Address'] = val;
                    if (lowerLabel.includes('order')) templateParams['Order Number (Optional)'] = val;

                    if (
                      lowerLabel === 'description of issue' || 
                      lowerLabel.includes('complaint') || 
                      lowerLabel.includes('issue') || 
                      lowerLabel.includes('message') ||
                      lowerLabel.includes('details') ||
                      field.type === 'TEXTAREA' ||
                      field.type === 'textarea'
                    ) {
                      templateParams['Complaint Details'] = val;
                    }
                    templateParams[field.label] = val;
                    templateParams[field.id] = val;

                    // Build a comprehensive string of all fields
                    allDetails += `${field.label}: ${val}\n`;
                  });
                  
                  // Add the formatted list of all inputs
                  templateParams['All_Details'] = allDetails;

                  // ULTIMATE FALLBACK: If Complaint Details is STILL somehow blank, 
                  // just dump all details into it so they don't lose data in old templates.
                  if (!templateParams['Complaint Details']) {
                    templateParams['Complaint Details'] = "\n" + allDetails;
                  }
                  
                  if (customerEmail && templateCustomer) {
                    const customerParams = { ...templateParams, to_email: customerEmail };
                    emailjs.send(serviceId, templateCustomer, customerParams, {
                      publicKey: publicKey
                    }).then(() => {
                      console.log("Customer email sent successfully via EmailJS!");
                    }).catch(err => {
                      console.error("Failed to send customer email", err);
                    });
                  }

                  if (shopEmail && templateMerchant) {
                    const merchantParams = { ...templateParams, to_email: shopEmail };
                    emailjs.send(serviceId, templateMerchant, merchantParams, {
                      publicKey: publicKey
                    }).then(() => {
                      console.log("Merchant email sent successfully via EmailJS!");
                    }).catch(err => {
                      console.error("Failed to send merchant email", err);
                    });
                  }
                } else {
                  console.warn("EmailJS skipped: Config could not be loaded from backend.");
                }
              } else {
                console.warn("EmailJS script not loaded.");
              }
            } catch (emailErr) {
              console.error("EmailJS error:", emailErr);
            }
          } else {
            throw new Error('Submission failed');
          }
        } catch (err) {
          const errorEl = document.getElementById(`ts-error-${blockId}`);
          errorEl.style.display = 'block';
          submitBtn.disabled = false;
          submitBtn.textContent = form.submitText || 'Submit';
        }
      });
      
    } catch (err) {
      if (err.message === 'NoPublishedForms') {
        container.innerHTML = `
          <div style="padding: 40px; text-align: center; background: #f4f6f8; border-radius: 8px;">
            <p style="margin: 0; color: #333; font-family: sans-serif;">No published forms yet — publish a form in the TrustStars app to display it here.</p>
          </div>
        `;
      } else {
        container.innerHTML = `<div class="ts-error-state">Unable to load form. Make sure your Form ID is correct.</div>`;
      }
    }
  });
}

// Run immediately if DOM is ready, otherwise wait for DOMContentLoaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initTrustStarsForms);
} else {
  initTrustStarsForms();
}

// Support for Shopify Theme Editor (Dynamic block additions)
document.addEventListener('shopify:section:load', initTrustStarsForms);
document.addEventListener('shopify:block:select', initTrustStarsForms);

